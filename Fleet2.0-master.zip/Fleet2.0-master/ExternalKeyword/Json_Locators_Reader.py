import json
import jsonpath


def Read_Locators_from_json(locatorname):
    f=open("D:/Python Directory/Fleet2.0/JsonFiles/Elements.json","r")
    response = json.loads(f.read())
    value= jsonpath.jsonpath(response,locatorname)
    return value