from selenium import webdriver
from webdriver_manager.firefox import GeckoDriverManager
from webdriver_manager.chrome import ChromeDriverManager
from webdriver_manager.microsoft import IEDriverManager
from webdriver_manager.microsoft import EdgeDriverManager
from selenium.webdriver.support.wait import WebDriverWait
from selenium.webdriver.common.by import By
from selenium.webdriver.support import expected_conditions as EC
import string

class BaseClass(object):
    _driver = None

    # def __init__(self,browser):
    #     self.browser=browser

    def __init__(self,browser):
        if (browser.lower())=="firefox":
            self._driver=webdriver.Firefox(executable_path=GeckoDriverManager().install())
            print("launching the url from selenium python on Firefox browser")

        elif browser=="chrome":
            self._driver=webdriver.Chrome(executable_path=ChromeDriverManager().install())
            print("launching the url from selenium python on Chrome browser")

        elif browser=="ie":
            self._driver=webdriver.Ie(executable_path=IEDriverManager().install())
            print("launching the url from selenium python on Internet Explorer browser")

        elif browser=="edge":
            self._driver=webdriver.Edge(executable_path=EdgeDriverManager().install())
            print("launching the url from selenium python on Microsoft edge browser")

    def get_web_element_by_xpath(self, xpath):
        return self._wait.until(EC.presence_of_element_located((By.XPATH, xpath)))

    def get_web_elements_by_xpath(self, xpath):
        return self._wait.until(EC.presence_of_all_elements_located((By.XPATH, xpath)))

    def open(self, path):
        self._driver.get(path)

    def close_all(self):
        self._driver.quit()


