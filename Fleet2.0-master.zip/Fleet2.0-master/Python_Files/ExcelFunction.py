import openpyxl
location = "../DataFile/TestCase.xlsx"

def readthefile(rownum,columnnum):
    wb= openpyxl.load_workbook(location)
    sheet=wb.active
    cell=sheet.cell(row=rownum,column=columnnum)
    return cell.value

def writethefile(rownum,columnnum,passvalue):
    wb=openpyxl.Workbook()
    sheet=wb.active
    c1=sheet.cell(row=rownum,column=columnnum,value=passvalue)
#    c1.value= passvalue
    wb.save(location)
    return c1.value
print(writethefile(2,5,'Pass'))