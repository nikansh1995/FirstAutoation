 http://localhost:8080/

 http://10.240.9.87:8080/job/testing/
 
 
 
 robot --variable firefox --output original-firefox.xml --report report-firefox.html live.robot
 robot --variable firefox --rerunfailed firefox.xml --output firefox1.xml --report firefox1.html live.robot
 rebot --output firefox.xml --merge firefox*.xml --report firefox.html --merge firefox*.html
 
 
 robot --output output-i.xml live.robot & robot --rerunfailed output-i.xml --output output-ii.xml live.robot
 rebot --merge --output output.xml -l log.html -r report.html output-i.xml output-ii.xml  
 
 
 robot --variable firefox --output output.xml live.robot
 robot --variable firefox --rerunfailed output.xml --output firefox.xml live.robot
 rebot --merge --output output.xml -l firefox-log.html -r firefox-report.html firefox.xml
 
 
 robot --variable firefox --output output1.xml TestCases
 robot --variable firefox --rerunfailed output1.xml --output output2.xml TestCases
 rebot --merge --output output.xml -l firefoxlog.html -r firefox.html --reporttitle "FLEET2 AUTOMATION REPORT" output1.xml output2.xml
                     AND FOR CHROME
 robot --variable chrome --output output3.xml TestCases
 robot --variable chrome --rerunfailed output3.xml --output output4.xml TestCases
 rebot --merge --output output.xml -l chromelog.html -r chrome.html --reporttitle "FLEET2 AUTOMATION REPORT" output3.xml output4.xml
 
 
 
 
 
 //td[contains(text(),'Robot')]//preceding::tr[@class='ng-star-inserted']//td[6]/span/button[3]
 //td[contains(text(),'Robot')]//parent::tr/td[6]//button[3]
 
 
 
 150084428
 REDMI5
 Android version: 8.1.0 OPM1.171019.026
 APP VERSION: 1.6
 
 